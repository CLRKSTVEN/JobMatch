<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport"
        content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=overlays-content">
  <title>TrabaWHO?</title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url('assets/vendors/mdi/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?= base_url('assets/vendors/css/vendor.bundle.base.css'); ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/vertical-light/style.css'); ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/universal.css') ?>">
  <link rel="shortcut icon" href="<?= base_url('assets/images/logo-small.png'); ?>" />

  <style>
    :root{ --blue:#0a22ff; --yellow:#ffe000; --ink:#14213d; --line:#e5e7eb; }

    body{ font-family:"Poppins",ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial; overflow-y:auto!important; }
    html, body { height:100%; margin:0; }
    .container-scroller, .page-body-wrapper, .content-wrapper, .auth { min-height:100vh; padding:0 !important; }
    .auth .row { margin:0 !important; }
    .auth .row.g-0 > [class*="col-"], .auth .row > [class*="col-"] { padding-left:0 !important; padding-right:0 !important; }

    /* ====== Right visual (mobile kept!) ====== */
    .login-visual{
      position:relative; display:flex; align-items:flex-end; justify-content:center;
      width:100%; min-height:52vh; overflow:hidden; border-radius:0;
      --fadeH: 38%;
    }
    .login-visual picture, .login-visual .visual-img{ position:absolute; inset:0; width:100%; height:100%; }
    .login-visual .visual-img{ object-fit:cover; object-position:center; transform:scale(1.02); }
    .login-visual::before{
      content:""; position:absolute; inset:0; pointer-events:none;
      background:linear-gradient(180deg, rgba(0,0,0,.08) 0%, rgba(0,0,0,.25) 60%, rgba(0,0,0,.35) 100%);
      opacity:.7;
    }
    .login-visual::after{
      content:""; position:absolute; left:0; right:0; bottom:0; height:var(--fadeH);
      background:linear-gradient(to bottom,
        rgba(10,34,255,0) 0%,
        rgba(10,34,255,.35) 40%,
        rgba(10,34,255,.75) 70%,
        rgba(10,34,255,1) 100%);
      pointer-events:none;
    }

    .brand-hero{
      position:absolute; z-index:3; left:50%; transform:translateX(-50%);
      bottom: calc(var(--fadeH) * 0.30);
      text-align:center; padding:0 1rem; pointer-events:none;
    }
    .brand-hero img{ width:min(82vw, 480px); height:auto; display:block; }

    /* ====== Carousel overlay (mobile + desktop) ====== */
    .jobs-carousel{
      position:absolute; left:50%; transform:translateX(-50%);
      z-index:4; width:min(92vw, 560px);
      bottom: calc(var(--fadeH) * 0.25);
      user-select:none;
    }
    .carousel-head{
      color:#fff; font-weight:700; margin:0 0 8px 6px; font-size:.95rem;
      text-shadow:0 1px 2px rgba(0,0,0,.45);
    }

    /* renamed to avoid Bootstrap collisions */
    .jobs-track  { position:relative; overflow:hidden; border-radius:14px; }
    .jobs-inner  { display:flex; transition:transform .45s ease; will-change:transform; }
    .job-slide   { flex:0 0 100%; min-width:100%; } /* ensure one full-width slide */
    .jobs-dots   { display:flex; gap:6px; justify-content:center; margin-top:8px; }

    .glass-card{
      background:rgba(17, 23, 41, .74);
      color:#fff;
      border:1px solid rgba(255,255,255,.14);
      border-radius:14px;
      box-shadow:0 12px 28px rgba(0,0,0,.28);
      backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);
      padding:14px 16px;
    }
    .glass-card .title{ font-weight:700; font-size:1rem; }
    .glass-card .muted{ color:#e5e7eb; opacity:.92; }
    .glass-card .meta{
      color:#cbd5e1; font-size:.85rem; display:flex; gap:12px; flex-wrap:wrap; margin:6px 0 6px;
    }

    /* External link pill */
    .ext-link{
      display:inline-flex; align-items:center; gap:.4rem;
      margin-top:8px;
      padding:.42rem .7rem;
      border-radius:9999px;
      background:rgba(255,255,255,.16);
      color:#fff; text-decoration:none; font-weight:700; font-size:.86rem;
      border:1px solid rgba(255,255,255,.25);
      backdrop-filter:blur(6px);
      word-break:break-word;
    }
    .ext-link:hover{ background:rgba(255,255,255,.24); }
    .ext-link .mdi{ font-size:18px; line-height:1; }

    .jobs-dots button{
      width:7px; height:7px; border-radius:999px; border:0; background:#cbd5e1; opacity:.65;
    }
    .jobs-dots button.active{ background:#fff; opacity:1; }

    .carousel-nav{
      position:absolute; inset:0; display:flex; align-items:center; justify-content:space-between;
      pointer-events:none;
    }
    .nav-btn{
      pointer-events:auto; width:36px; height:36px; border-radius:50%;
      display:flex; align-items:center; justify-content:center;
      border:1px solid rgba(255,255,255,.35);
      background:rgba(15,23,42,.52); color:#fff;
      box-shadow:0 4px 14px rgba(0,0,0,.22);
    }
    .nav-btn:hover{ background:rgba(15,23,42,.7); }
    .nav-btn#prevD{ margin-left:6px; } .nav-btn#nextD{ margin-right:6px; }

    /* ====== Desktop tweaks ====== */
    @media (min-width: 992px){
      .login-visual{ min-height:100vh; }
      .brand-hero{ display:none; }
      .login-visual::after{ display:none; }
      .jobs-carousel{ bottom:32px; }
    }

    /* ====== Left/form column (mobile look retained) ====== */
    @media (max-width: 991.98px){
      .auth{ background:var(--blue); }
      .auth-form-transparent{ color:#fff; }
      .auth-form-transparent .brand-logo{ display:none;  }
      .auth-form-transparent label{ color:#e7e9ff; font-weight:600; }
      .auth-form-transparent a.text-primary{ color:#fff !important; text-decoration:none; }
      .auth .fw-light{ color:#fff; }
      .auth-form-transparent .form-control{
        border-radius:9999px !important;
        padding:.9rem 1.2rem !important;
        border:0 !important;
      }
      .auth-form-btn.btn-primary{
        background:var(--yellow) !important; border-color:var(--yellow) !important;
        color:var(--ink) !important; border-radius:9999px !important; font-weight:700;
        padding:.9rem 1.1rem;
      }
      .auth-form-btn.btn-primary:hover{ filter:brightness(0.95); }

      .auth-form-transparent form.pt-3{
        padding-top:0 !important;
        transform:translateY(-50px);
        will-change:transform;
      }
      .page-body-wrapper.full-page-wrapper .content-wrapper.auth{ margin-top:-60px !important; }

      .auth-form-transparent .form-field .form-control{ padding-left:3.25rem !important; }
      .auth-form-transparent .form-field .field-icon{ left:.9rem; font-size:1.15rem; }

      .carousel-nav{ display:none; } /* hide arrows on mobile */
    }

    .page-body-wrapper, .content-wrapper { padding-top:0 !important; margin-top:0 !important; }
    .login-visual img, .login-visual picture { display:block; }
    .login-visual picture, .login-visual .visual-img{ top:10px; height:calc(100% + 2px); }

    @supports (padding: max(0px)){
      .login-visual{
        padding-top:env(safe-area-inset-top);
        margin-top:calc(-1 * env(safe-area-inset-top));
      }
    }

    /* inputs */
    .auth-card{ max-width:520px; width:100%; }
    .form-field{ position:relative; }
    .form-field .field-icon{
      position:absolute; left:16px; top:50%; transform:translateY(-50%);
      font-size:20px; color:#6b7280; pointer-events:none;
    }
    .form-field .form-control{ padding-left:48px !important; background:#fff !important; color:#111 !important; }
    .form-control::placeholder{ color:#9aa3b2; opacity:1; }
    .form-field .toggle-eye{
      position:absolute; right:12px; top:50%; transform:translateY(-50%);
      width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center;
      border:0; background:transparent; cursor:pointer; color:#6b7280;
    }
    .form-field .toggle-eye:hover{ color:#111; }
    .form-field .toggle-eye:focus{ outline:0; box-shadow:0 0 0 3px rgba(59,130,246,.25); border-radius:8px; }
    .form-field .form-control{ padding-right:3rem !important; }
  </style>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth">
        <div class="row g-0 flex-grow w-100 align-items-center">

          <!-- RIGHT: hero + brand + overlay carousel -->
          <div class="col-lg-6 p-0 order-1 order-lg-2">
            <section class="login-visual" role="region" aria-roledescription="carousel" aria-label="Latest Job Vacancies">
              <picture aria-hidden="true">
                <source media="(max-width: 991.98px)" srcset="<?= base_url('assets/images/girlphone.jpg'); ?>">
                <img class="visual-img" src="<?= base_url('assets/images/job-matching.png'); ?>" alt="">
              </picture>

              <div class="brand-hero d-lg-none" style="text-align:center;">
                <img src="<?= base_url('assets/images/logo-white.png'); ?>" alt="TrabaWho?">
              </div>

              <div id="jobs-carousel" class="jobs-carousel" style="display:none;">
                <h6 class="carousel-head">Latest Job Vacancies</h6>
                <div class="jobs-track">
                  <div class="jobs-inner" id="jobs-inner"></div>
                  <div class="carousel-nav">
                    <button type="button" class="nav-btn" id="prevD" aria-label="Previous"><i class="mdi mdi-chevron-left"></i></button>
                    <button type="button" class="nav-btn" id="nextD" aria-label="Next"><i class="mdi mdi-chevron-right"></i></button>
                  </div>
                </div>
                <div class="jobs-dots" id="jobs-dots"></div>
              </div>
            </section>
          </div>

          <!-- LEFT: login form -->
          <div class="col-lg-6 d-flex align-items-center justify-content-center px-4 px-md-5 order-2 order-lg-1">
            <div class="auth-form-transparent text-left p-3 auth-card">

              <div class="brand-logo mb-3 d-none d-lg-block">
                <img src="<?= base_url('assets/images/trabawhotext.png'); ?>" alt="TrabaWho?" style="width:280px;height:auto;">
              </div>

              <?php foreach (['success' => 'success', 'error' => 'danger', 'info' => 'info', 'msg' => 'success'] as $key => $class): ?>
                <?php if ($this->session->flashdata($key)): ?>
                  <?php $isSticky = ($key === 'msg'); ?>
                  <div class="alert alert-<?= $class ?> fade show small mb-3 <?= $isSticky ? 'alert-sticky' : 'autoclose' ?>" role="alert">
                    <?= htmlspecialchars($this->session->flashdata($key), ENT_QUOTES, 'UTF-8') ?>
                    <?php if (!$isSticky): ?>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php endif; ?>
                  </div>
                <?php endif; ?>
              <?php endforeach; ?>

              <?php if (validation_errors()): ?>
                <div class="alert alert-danger small mb-3">
                  <?= validation_errors(); ?>
                </div>
              <?php endif; ?>

              <?= form_open('auth/login', ['class' => 'pt-3']); ?>
                <?php if (isset($this->security)): ?>
                  <input type="hidden"
                         name="<?= $this->security->get_csrf_token_name(); ?>"
                         value="<?= $this->security->get_csrf_hash(); ?>">
                <?php endif; ?>

                <div class="form-group">
                  <label for="email">Email Address</label>
                  <div class="form-field">
                    <i class="mdi mdi-email-outline field-icon" aria-hidden="true"></i>
                    <input type="text"
                           class="form-control form-control-lg"
                           id="email" name="email"
                           value="<?= set_value('email'); ?>"
                           placeholder="Email"
                           autocomplete="username" required>
                  </div>
                  <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                  <label for="password">Password</label>
                  <div class="form-field">
                    <i class="mdi mdi-lock-outline field-icon" aria-hidden="true"></i>
                    <input type="password"
                           class="form-control form-control-lg"
                           id="password" name="password"
                           placeholder="Password"
                           autocomplete="current-password" required>

                    <button type="button"
                            class="toggle-eye"
                            aria-label="Show password"
                            data-target="#password">
                      <i class="mdi mdi-eye-outline" aria-hidden="true" style="font-size:20px"></i>
                    </button>
                  </div>

                  <a href="<?= site_url('auth/forgot'); ?>" class="text-primary">Forgot password?</a>
                  <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="my-3 d-grid gap-2">
                  <button type="submit" class="btn btn-primary btn-lg fw-medium auth-form-btn">Login</button>
                </div>

                <div class="text-center mt-4 fw-light">
                  Don't have an account?
                  <a href="<?= site_url('auth/signup'); ?>" class="text-primary">Create</a>
                </div>
              <?= form_close(); ?>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Vendor JS -->
  <script src="<?= base_url('assets/vendors/js/vendor.bundle.base.js'); ?>"></script>
  <script src="<?= base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?= base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?= base_url('assets/js/misc.js'); ?>"></script>
  <script src="<?= base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?= base_url('assets/js/todolist.js'); ?>"></script>

  <!-- Password eye -->
  <script>
    (function(){
      var btn   = document.querySelector('.toggle-eye[data-target="#password"]');
      var input = document.querySelector('#password');
      if(!btn || !input) return;
      btn.addEventListener('click', function(){
        var isPwd = input.type === 'password';
        input.type = isPwd ? 'text' : 'password';
        var icon = btn.querySelector('.mdi');
        if(icon){
          icon.classList.remove(isPwd ? 'mdi-eye-outline' : 'mdi-eye-off-outline');
          icon.classList.add(isPwd ? 'mdi-eye-off-outline' : 'mdi-eye-outline');
        }
        btn.setAttribute('aria-label', isPwd ? 'Hide password' : 'Show password');
      });
    })();
  </script>

  <!-- Auto-close non-sticky alerts -->
  <script>
    setTimeout(function () {
      document.querySelectorAll('.alert.autoclose').forEach(function (el) {
        var bsAlert = bootstrap.Alert.getOrCreateInstance(el);
        bsAlert.close();
      });
    }, 4000);
  </script>

  <!-- Feed + unified carousel (mobile & desktop) with DOM-based slides -->
  <script>
    (function(){
      // Safer text; template-literal-proof
      const fmt = (s) => String(s || '')
        .replace(/[<>&]/g, '')      // remove basic tags
        .replace(/`/g, 'ʼ')         // neutralize backticks
        .replace(/\$\{/g, '﹛')     // neutralize ${
        .trim();

      function sanitizeUrl(raw){
        if(!raw) return '';
        let u = String(raw).trim();
        if(!/^https?:\/\//i.test(u)) u = 'https://' + u; // allow plain domains
        return u;
      }

      function makeSlideNode(j){
        const slide = document.createElement('div');
        slide.className = 'job-slide';

        const card = document.createElement('div');
        card.className = 'glass-card';
        slide.appendChild(card);

        // Title
        const title = document.createElement('div');
        title.className = 'title';
        title.textContent = (j && j.title) ? j.title : '';
        card.appendChild(title);

        // Created at
        const small = document.createElement('div');
        small.className = 'muted small';
        small.textContent = (j && j.created_at) ? String(j.created_at).replace('T',' ') : '';
        card.appendChild(small);

        // Meta (location + price)
        const meta = document.createElement('div');
        meta.className = 'meta';
        card.appendChild(meta);

        if (j && j.location_text){
          const spanLoc = document.createElement('span');
          spanLoc.innerHTML = '<i class="mdi mdi-map-marker"></i> ' + fmt(j.location_text);
          meta.appendChild(spanLoc);
        }

        const hasMin = (j && j.price_min !== null && j.price_min !== undefined && j.price_min !== '');
        const hasMax = (j && j.price_max !== null && j.price_max !== undefined && j.price_max !== '');
        if (hasMin || hasMax){
          const spanPrice = document.createElement('span');
          const range = (hasMin && hasMax)
            ? `₱ ${j.price_min} - ${j.price_max}`
            : `₱ ${hasMin ? j.price_min : j.price_max}`;
          spanPrice.innerHTML = '<i class="mdi mdi-cash"></i> ' + range;
          meta.appendChild(spanPrice);
        }

        // Description (clamped)
        const desc = document.createElement('div');
        desc.className = 'muted small';
        desc.style.webkitLineClamp = '3';
        desc.style.display = '-webkit-box';
        desc.style.webkitBoxOrient = 'vertical';
        desc.style.overflow = 'hidden';
        desc.textContent = (j && j.description) ? j.description : '';
        card.appendChild(desc);

        // Optional external link
        const rawUrl = (j && (j.website_url || j.url || j.link)) ? (j.website_url || j.url || j.link) : '';
        const safe = sanitizeUrl(rawUrl);
        if (safe){
          const a = document.createElement('a');
          a.className = 'ext-link';
          a.target = '_blank';
          a.rel = 'noopener';
          a.href = safe;
          a.innerHTML = '<i class="mdi mdi-open-in-new"></i> Apply / Website';
          card.appendChild(a);
        }

        return slide;
      }

      function buildDots(cnt, dotsEl){
        dotsEl.innerHTML='';
        for(let i=0;i<cnt;i++){
          const b=document.createElement('button');
          if(i===0) b.classList.add('active');
          dotsEl.appendChild(b);
        }
      }

      function startCarousel(innerEl, dotsEl, prevBtn, nextBtn, intervalMs){
        const slides = innerEl.children.length;
        if(!slides) return;
        let idx=0, timer=null;

        function go(i){
          idx = (i+slides)%slides;
          innerEl.style.transform = `translateX(-${idx*100}%)`;
          if (dotsEl){
            [...dotsEl.children].forEach((d,k)=>d.classList.toggle('active', k===idx));
          }
        }
        function start(){ timer = setInterval(()=>go(idx+1), intervalMs); }
        function stop(){ if(timer){ clearInterval(timer); timer=null; } }

        innerEl.addEventListener('mouseenter', stop);
        innerEl.addEventListener('mouseleave', start);

        if (prevBtn) prevBtn.addEventListener('click', ()=>{ stop(); go(idx-1); start(); });
        if (nextBtn) nextBtn.addEventListener('click', ()=>{ stop(); go(idx+1); start(); });

        // touch swipe
        let x0=null;
        innerEl.addEventListener('touchstart', e=>{ x0=e.touches[0].clientX; stop(); }, {passive:true});
        innerEl.addEventListener('touchend', e=>{
          if(x0===null) return;
          const dx=(e.changedTouches[0].clientX - x0);
          if(Math.abs(dx)>40){ go(idx + (dx<0?1:-1)); }
          x0=null; start();
        });

        start();
      }

      fetch('<?= site_url('peso/feed'); ?>', { headers: { 'Accept':'application/json' }})
        .then(r => r.ok ? r.text() : Promise.reject())
        .then(t => { try { return JSON.parse(t); } catch(e){ return { ok:false }; }})
        .then(json => {
          if(!json || !json.ok) return;
          const list = Array.isArray(json.data) ? json.data : [];
          if(!list.length) return;

          const wrap  = document.getElementById('jobs-carousel');
          const inner = document.getElementById('jobs-inner');
          const dots  = document.getElementById('jobs-dots');
          const prevD = document.getElementById('prevD');
          const nextD = document.getElementById('nextD');

          if (wrap && inner){
            // Clear and populate using DOM nodes (no innerHTML/templates)
            while (inner.firstChild) inner.removeChild(inner.firstChild);
            list.forEach(item => inner.appendChild(makeSlideNode(item)));

            // sanity check
            console.log('slides count:', inner.children.length);

            wrap.style.display = 'block';
            buildDots(list.length, dots);
            startCarousel(inner, dots, prevD, nextD, 4800);
          }
        })
        .catch(()=>{ /* silent */ });
    })();
  </script>
</body>
</html>
