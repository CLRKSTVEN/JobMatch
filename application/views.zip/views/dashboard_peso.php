<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <?php $page_title = $page_title ?? 'PESO Dashboard'; ?>
  <title><?= htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8') ?></title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url('assets/vendors/mdi/css/materialdesignicons.min.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/vendors/css/vendor.bundle.base.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/vertical-light/style.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/custom.css?v=5.1.1') ?>">
  <link rel="shortcut icon" href="<?= base_url('assets/images/logo.png') ?>" />
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    :root{--ink:#0f172a;--muted:#6b7280;--line:#e5e7eb;--ring:#dbeafe;--primary:#2563eb;--primary-600:#2563eb;--primary-700:#1d4ed8;--card:#fff;--card-br:#e5e7eb;--hover:rgba(2,6,23,.03);--danger:#dc2626;}
    body{font-family:"Poppins",system-ui,-apple-system,"Segoe UI",Roboto,Arial;background:#f8fafc;color:#0f172a;}
    .admin-header{position:sticky;top:0;z-index:40;background:#fff;border-bottom:1px solid var(--line);}
    .card{background:var(--card);border:1px solid var(--card-br);border-radius:16px;box-shadow:0 1px 2px rgba(0,0,0,.04);}
    .btn{display:inline-flex;align-items:center;gap:.5rem;border-radius:10px;padding:.55rem .95rem;font-weight:700;border:1px solid transparent;transition:all .15s ease;}
    .btn-primary{background:var(--primary-600);border-color:var(--primary-600);color:#fff;}
    .btn-primary:hover{background:var(--primary-700);border-color:var(--primary-700);}
    .btn-ghost{background:#fff;border:1px solid var(--line);color:#111827;}
    .btn-ghost:hover{background:var(--hover);}
    .btn-icon{padding:.45rem .6rem;border-radius:10px;border:1px solid var(--line);background:#fff;}
    .badge{border-radius:999px;padding:.18rem .6rem;font-size:.72rem;font-weight:700;display:inline-flex;align-items:center;gap:.35rem;}
    .badge-open{background:rgba(5,150,105,.12);color:#065f46;}
    .badge-closed{background:rgba(55,65,81,.12);color:#374151;}
    .badge-public{background:rgba(37,99,235,.12);color:#1d4ed8;}
    .badge-followers{background:rgba(217,119,6,.12);color:#92400e;}
    .table thead th{font-weight:700;color:#374151;border-bottom:1px solid var(--line)!important;}
    .table tbody tr:hover{background:var(--hover);}
    .muted{color:#64748b;}
    .form-control{border-radius:10px;}
    .tw-modal-backdrop{position:fixed;inset:0;background:rgba(2,6,23,.55);display:none;align-items:center;justify-content:center;z-index:2000;padding:1rem;}
    .tw-modal-backdrop.show{display:flex;}
    .tw-modal-card{width:100%;max-width:560px;background:#fff;border:1px solid var(--card-br);border-radius:16px;box-shadow:0 10px 30px rgba(2,6,23,.18);overflow:hidden;transform:translateY(8px) scale(.98);opacity:0;transition:.18s ease;}
    .tw-modal-backdrop.show .tw-modal-card{transform:translateY(0) scale(1);opacity:1;}
    .tw-modal-header{display:flex;align-items:center;justify-content:space-between;gap:.75rem;padding:.9rem 1.1rem;border-bottom:1px solid var(--line);}
    .tw-modal-title{font-weight:700;font-size:1rem;display:flex;align-items:center;gap:.5rem;}
    .tw-modal-body{padding:1rem 1.1rem;}
    .tw-modal-footer{display:flex;justify-content:flex-end;gap:.5rem;padding:.8rem 1.1rem;border-top:1px solid var(--line);}
    .tw-close{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;border:1px solid var(--line);background:#fff;cursor:pointer;}
    .tw-close:hover{background:var(--hover);}
    .tw-grid-2{display:grid;grid-template-columns:1fr;gap:.8rem;}
    @media (min-width: 768px){.tw-grid-2{grid-template-columns:1fr 1fr;}}
    .field-group{display:flex;flex-direction:column;gap:.35rem;}
    .field-label{font-weight:600;font-size:.9rem;}
    .actions-cell{min-width:160px;text-align:right;}
    .iconbar{display:flex;gap:.4rem;justify-content:flex-end;flex-wrap:wrap;}
    .iconbtn{--size:38px;width:var(--size);height:var(--size);display:inline-flex;align-items:center;justify-content:center;border-radius:12px;border:1px solid var(--line);background:#fff;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease,transform .05s ease;position:relative;text-decoration:none;cursor:pointer;color:#111827;}
    .iconbtn .mdi{font-size:18px;line-height:1;}
    .iconbtn:hover{background:var(--hover);box-shadow:0 2px 6px rgba(2,6,23,.06);}
    .iconbtn.-primary{border-color:#c7d2fe;background:#eef2ff;color:#1e1b4b;}
    .iconbtn.-primary:hover{background:#e0e7ff;}
    .iconbtn.-danger{border-color:#fecaca;background:#fee2e2;color:#7f1d1d;}
    .iconbtn.-danger:hover{background:#fecaca;}
    .iconbtn[data-tip]::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%) translateY(4px);padding:.28rem .5rem;font-size:.75rem;font-weight:600;white-space:nowrap;background:#0f172a;color:#fff;border-radius:8px;opacity:0;pointer-events:none;box-shadow:0 6px 18px rgba(2,6,23,.18);transition:opacity .12s ease,transform .12s ease;}
    .iconbtn[data-tip]:hover::after{opacity:1;transform:translateX(-50%) translateY(0);}
    .iconbtn[data-tip]::before{content:"";position:absolute;bottom:100%;left:50%;transform:translateX(-50%);border:6px solid transparent;border-top-color:#0f172a;opacity:0;transition:opacity .12s ease;}
    .iconbtn[data-tip]:hover::before{opacity:1;}
    .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
  </style>
</head>

<body>
  <div class="container-scroller">
    <?php $this->load->view('includes/nav'); ?>
    <div class="container-fluid page-body-wrapper">
      <?php $this->load->view('includes/nav-top'); ?>
      <div class="main-panel">
        <?php
          $__addr_rows = $this->db
            ->select('AddID, Province, City, Brgy')
            ->from('settings_address')
            ->order_by('Province, City, Brgy', 'ASC')
            ->get()->result_array();
        ?>
        <script>
          window.ADDRESS_DATA = <?= json_encode($__addr_rows, JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;
        </script>

        <div class="content-wrapper pb-0">
          <div class="px-4 md:px-8 max-w-7xl mx-auto">
            <div class="admin-header">
              <div class="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div>
                  <h1 class="text-2xl md:text-3xl font-bold"><?= htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8') ?></h1>
                  <p class="text-sm muted mt-1">Manage your PESO job vacancies. Only <b>OPEN</b> + <b>PUBLIC</b> posts appear on the login page feed.</p>
                </div>
                <div class="flex items-center gap-2">
                  <button type="button" class="btn btn-primary" id="openCreateModalBtn">
                    <i class="mdi mdi-briefcase-plus"></i> New Vacancy
                  </button>
                  <a class="btn btn-ghost" href="<?= site_url('dashboard/peso') ?>">
                    <i class="mdi mdi-refresh"></i> Refresh
                  </a>
                </div>
              </div>
            </div>

            <?php
              $k_open = isset($k_open) ? (int)$k_open : 0;
              $k_closed = isset($k_closed) ? (int)$k_closed : 0;
              $k_public = isset($k_public) ? (int)$k_public : 0;
            ?>

            <section class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div class="card p-4"><div class="text-sm muted">Open Positions</div><div class="mt-1 text-2xl font-bold"><?= number_format($k_open) ?></div></div>
              <div class="card p-4"><div class="text-sm muted">Closed Positions</div><div class="mt-1 text-2xl font-bold"><?= number_format($k_closed) ?></div></div>
              <div class="card p-4"><div class="text-sm muted">Public Posts</div><div class="mt-1 text-2xl font-bold"><?= number_format($k_public) ?></div></div>
            </section>

            <div class="mt-4">
              <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <?= $this->session->flashdata('success'); ?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
              <?php endif; ?>
              <?php if ($this->session->flashdata('danger')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <?= $this->session->flashdata('danger'); ?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
              <?php endif; ?>
            </div>

            <section class="mt-4">
              <div class="card p-5">
                <div class="flex items-center justify-between mb-4">
                  <div>
                    <h3 class="text-lg font-semibold">My Job Vacancies</h3>
                    <p class="text-xs muted">Latest first</p>
                  </div>
                  <form method="get" action="" class="hidden md:flex items-center gap-2">
                    <input type="text" name="q" class="form-control" placeholder="Search title or location">
                    <button class="btn btn-ghost" type="submit"><i class="mdi mdi-magnify"></i> Search</button>
                  </form>
                </div>

                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Title &amp; Details</th>
                        <th>Status</th>
                        <th>Visibility</th>
                        <th>Posted</th>
                        <th style="width:220px">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (!empty($list)): foreach ($list as $r): ?>
                        <?php
                          $id       = (int)$r['id'];
                          $title    = html_escape($r['title']);
                          $desc     = isset($r['description']) ? html_escape($r['description']) : '';
                          $site     = isset($r['website_url']) ? trim((string)$r['website_url']) : '';
                          $siteSafe = html_escape($site);
                          $loc      = !empty($r['location_text']) ? html_escape($r['location_text']) : '';
                          $min      = ($r['price_min']!==null) ? (float)$r['price_min'] : null;
                          $max      = ($r['price_max']!==null) ? (float)$r['price_max'] : null;
                          $minF     = $min!==null ? number_format($min, 2) : '';
                          $maxF     = $max!==null ? number_format($max, 2) : '';
                          $status   = strtolower((string)$r['status']) === 'open' ? 'open' : 'closed';
                          $post_type= isset($r['post_type']) ? strtolower((string)$r['post_type']) : 'hire';
                          $visRaw   = isset($r['visibility']) ? strtolower((string)$r['visibility']) : 'public';
                          $vis      = in_array($visRaw, ['public','followers'], true) ? $visRaw : 'public';
                          $posted   = html_escape($r['created_at']);
                          $isOpen   = ($status === 'open');
                          $toggleIcon = $isOpen ? 'mdi-toggle-switch' : 'mdi-toggle-switch-off-outline';
                          $toggleTip  = $isOpen ? 'Close' : 'Open';
                        ?>
                        <tr>
                          <td>
                            <div class="font-semibold"><?= $title ?></div>
                            <div class="mt-1 text-sm muted flex flex-col gap-0.5">
                              <?php if ($loc): ?><div><i class="mdi mdi-map-marker"></i> <?= $loc ?></div><?php endif; ?>
                              <?php if ($minF !== '' || $maxF !== ''): ?>
                                <div><i class="mdi mdi-cash"></i> ₱ <?= $minF ?><?= ($minF!=='' && $maxF!=='') ? ' - ' : '' ?><?= $maxF ?></div>
                              <?php endif; ?>
                            </div>
                            <?php if ($site): ?>
                              <div class="mt-1 text-sm">
                                <a href="<?= $siteSafe ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-1 text-blue-600 hover:underline">
                                  <i class="mdi mdi-open-in-new"></i> Visit posting
                                </a>
                              </div>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if ($status === 'open'): ?>
                              <span class="badge badge-open"><i class="mdi mdi-checkbox-blank-circle"></i> OPEN</span>
                            <?php else: ?>
                              <span class="badge badge-closed"><i class="mdi mdi-checkbox-blank-circle"></i> CLOSED</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if ($vis === 'public'): ?>
                              <span class="badge badge-public"><i class="mdi mdi-earth"></i> Public</span>
                            <?php else: ?>
                              <span class="badge badge-followers"><i class="mdi mdi-account-multiple"></i> Followers</span>
                            <?php endif; ?>
                          </td>
                          <td class="text-sm muted"><?= $posted ?></td>
                          <td class="actions-cell">
                            <div class="iconbar">
                            <button
  type="button"
  class="iconbtn -primary editVacancyBtn"
  data-tip="Edit"
  aria-label="Edit"
  title="Edit"
  data-id="<?= $id ?>"
  data-title="<?= $title ?>"
  data-description="<?= $desc ?>"
  data-website_url="<?= $siteSafe ?>"
  data-post_type="<?= $post_type ?>"
  data-visibility="<?= $vis ?>"
  data-price_min="<?= $min!==null ? $min : '' ?>"
  data-price_max="<?= $max!==null ? $max : '' ?>"
  data-location_text="<?= $loc ?>"
>
  <i class="mdi mdi-pencil"></i><span class="sr-only">Edit</span>
</button>

                              <a href="<?= site_url('peso/toggle/'.$id) ?>" class="iconbtn" data-tip="<?= $toggleTip ?>" aria-label="<?= $toggleTip ?>" title="<?= $toggleTip ?>">
                                <i class="mdi <?= $toggleIcon ?>"></i><span class="sr-only"><?= $toggleTip ?></span>
                              </a>
                              <a href="<?= site_url('peso/delete/'.$id) ?>" onclick="return confirm('Delete this posting?');" class="iconbtn -danger" data-tip="Delete" aria-label="Delete" title="Delete">
                                <i class="mdi mdi-delete-outline"></i><span class="sr-only">Delete</span>
                              </a>
                            </div>
                          </td>
                        </tr>
                      <?php endforeach; else: ?>
                        <tr><td colspan="5" class="text-center muted">No postings yet.</td></tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>

                <p class="mt-4 text-sm muted"><i class="mdi mdi-information-outline"></i> Only <strong>OPEN</strong> and <strong>PUBLIC</strong> vacancies are shown on the login screen feed.</p>
              </div>
            </section>

            <div class="my-8" style="height:1px;background:var(--line)"></div>
          </div>
        </div>

        <?php $this->load->view('includes/footer'); ?>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div id="vacancyModal" class="tw-modal-backdrop" aria-hidden="true">
    <div class="tw-modal-card" role="dialog" aria-modal="true" aria-labelledby="vacancyModalTitle">
      <div class="tw-modal-header">
        <div class="tw-modal-title" id="vacancyModalTitle">
          <i class="mdi mdi-briefcase-plus"></i>
          <span id="modalModeTitle">Create Job Vacancy</span>
        </div>
        <button type="button" class="tw-close" id="modalCloseBtn" title="Close">
          <i class="mdi mdi-close"></i>
        </button>
      </div>

      <form id="vacancyForm" method="post" action="<?= site_url('peso/store') ?>">
        <div class="tw-modal-body">
          <input type="hidden" name="id" id="v_id" />

          <div class="field-group">
            <label class="field-label" for="v_title">Job Title *</label>
            <input type="text" name="title" id="v_title" class="form-control" required placeholder="e.g., Junior Web Developer">
          </div>

          <div class="field-group" style="margin-top:.8rem;">
            <label class="field-label" for="v_description">Description</label>
            <textarea name="description" id="v_description" rows="4" class="form-control" placeholder="Short role overview, qualifications, responsibilities"></textarea>
          </div>

          <!-- NEW: Website (optional) -->
          <div class="field-group" style="margin-top:.8rem;">
            <label class="field-label" for="v_website_url">Website Links</label>
            <input type="url" name="website_url" id="v_website_url" class="form-control" placeholder="https://example.com/job/123">
            <small class="muted">Add a link to the external job post.</small>
          </div>

          <div class="tw-grid-2" style="margin-top:.8rem;">
            <div class="field-group">
              <label class="field-label" for="v_post_type">Post Type</label>
              <select name="post_type" id="v_post_type" class="form-control">
                <option value="hire">Hire</option>
                <option value="service">Service</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label" for="v_visibility">Visibility</label>
              <select name="visibility" id="v_visibility" class="form-control">
                <option value="public">Public</option>
                <option value="followers">Followers</option>
              </select>
            </div>
          </div>

          <div class="tw-grid-2" style="margin-top:.8rem;">
            <div class="field-group">
              <label class="field-label" for="v_price_min">Salary Min</label>
              <input type="number" step="0.01" name="price_min" id="v_price_min" class="form-control" placeholder="e.g., 15000">
            </div>
            <div class="field-group">
              <label class="field-label" for="v_price_max">Salary Max</label>
              <input type="number" step="0.01" name="price_max" id="v_price_max" class="form-control" placeholder="e.g., 25000">
            </div>
          </div>

          <div class="tw-grid-2" style="margin-top:.8rem;">
            <div class="field-group">
              <label class="field-label" for="v_province">Province</label>
              <select id="v_province" class="form-control">
                <option value="">Select Province</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label" for="v_city">City/Municipality</label>
              <select id="v_city" class="form-control" disabled>
                <option value="">Select City/Municipality</option>
              </select>
            </div>
          </div>

          <div class="tw-grid-2" style="margin-top:.8rem;">
            <div class="field-group">
              <label class="field-label" for="v_brgy">Barangay</label>
              <select id="v_brgy" class="form-control" disabled>
                <option value="">Select Barangay</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label" for="v_location_text">Location (auto)</label>
              <input type="text" name="location_text" id="v_location_text" class="form-control" placeholder="Barangay, City, Province" readonly>
              <input type="hidden" id="v_address_id">
            </div>
          </div>
        </div>

        <div class="tw-modal-footer">
          <button type="button" class="btn btn-ghost" id="modalCancelBtn"><i class="mdi mdi-close"></i> Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="mdi mdi-content-save"></i> <span id="modalSubmitText">Post Vacancy</span></button>
        </div>
      </form>
    </div>
  </div>

  <script src="<?= base_url('assets/vendors/js/vendor.bundle.base.js') ?>"></script>
  <script src="<?= base_url('assets/js/off-canvas.js') ?>"></script>
  <script src="<?= base_url('assets/js/hoverable-collapse.js') ?>"></script>
  <script src="<?= base_url('assets/js/misc.js') ?>"></script>

  <script>
    (function(){
      const $backdrop = document.getElementById('vacancyModal');
      const $card = $backdrop.querySelector('.tw-modal-card');
      const $close = document.getElementById('modalCloseBtn');
      const $cancel = document.getElementById('modalCancelBtn');
      const $openCreate = document.getElementById('openCreateModalBtn');

      const form = document.getElementById('vacancyForm');
      const f_id   = document.getElementById('v_id');
      const f_title= document.getElementById('v_title');
      const f_desc = document.getElementById('v_description');
      const f_site = document.getElementById('v_website_url');     // NEW
      const f_type = document.getElementById('v_post_type');
      const f_vis  = document.getElementById('v_visibility');
      const f_min  = document.getElementById('v_price_min');
      const f_max  = document.getElementById('v_price_max');
      const f_loc  = document.getElementById('v_location_text');

      const $modeTitle = document.getElementById('modalModeTitle');
      const $submitText= document.getElementById('modalSubmitText');

      function openModal(){
        $backdrop.classList.add('show');
        setTimeout(()=>{ f_title && f_title.focus(); }, 80);
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
      }
      function closeModal(){
        $backdrop.classList.remove('show');
        document.documentElement.style.overflow = '';
        document.body.style.overflow = '';
      }

      function setModeCreate(){
        $modeTitle.textContent = 'Create Job Vacancy';
        $submitText.textContent = 'Post Vacancy';
        form.action = "<?= site_url('peso/store') ?>";
        f_id.value = '';
        f_title.value = '';
        f_desc.value = '';
        f_site.value = '';                   // NEW
        f_type.value = 'hire';
        f_vis.value = 'public';
        f_min.value = '';
        f_max.value = '';
        f_loc.value = '';
        if (window.__loc_reset) window.__loc_reset();
      }

      function setModeEdit(d){
        $modeTitle.textContent = 'Update Job Vacancy';
        $submitText.textContent = 'Save Changes';
        form.action = "<?= site_url('peso/update') ?>/" + (d.id || '');
        f_id.value = d.id || '';
        f_title.value = d.title || '';
        f_desc.value = d.description || '';
        f_site.value = d.website_url || '';  // NEW
        f_type.value = d.post_type || 'hire';
        f_vis.value = d.visibility || 'public';
        f_min.value = d.price_min || '';
        f_max.value = d.price_max || '';
        f_loc.value = d.location_text || '';
        if (window.__loc_loadFromText) window.__loc_loadFromText(d.location_text || '');
      }

      if ($openCreate){
        $openCreate.addEventListener('click', function(e){
          e.preventDefault();
          setModeCreate();
          openModal();
        });
      }

      document.querySelectorAll('.editVacancyBtn').forEach(function(btn){
        btn.addEventListener('click', function(e){
          e.preventDefault();
          const d = btn.dataset;
          setModeEdit(d);
          openModal();
        });
      });

      [$close, $cancel].forEach(function(el){
        if (el) el.addEventListener('click', closeModal);
      });
      $backdrop.addEventListener('click', function(e){
        if (! $card.contains(e.target)) closeModal();
      });
      document.addEventListener('keydown', function(e){
        if (e.key === 'Escape' && $backdrop.classList.contains('show')) closeModal();
      });
      $card.addEventListener('click', function(e){ e.stopPropagation(); });

      window.setModeCreate = setModeCreate;
      window.setModeEdit   = setModeEdit;
    })();
  </script>

  <script>
    (function(){
      const unique = (arr) => Array.from(new Set(arr));
      const byProv = (prov) => window.ADDRESS_DATA.filter(r => r.Province === prov);
      const byProvCity = (prov, city) => window.ADDRESS_DATA.filter(r => r.Province === prov && r.City === city);

      const selProv = document.getElementById('v_province');
      const selCity = document.getElementById('v_city');
      const selBrgy = document.getElementById('v_brgy');
      const txtLoc  = document.getElementById('v_location_text');
      const hidAdd  = document.getElementById('v_address_id');

      function resetCity() {
        selCity.innerHTML = '<option value="">Select City/Municipality</option>';
        selCity.disabled = true;
      }
      function resetBrgy() {
        selBrgy.innerHTML = '<option value="">Select Barangay</option>';
        selBrgy.disabled = true;
      }
      function composeLocation() {
        const p = selProv?.value || '';
        const c = selCity?.value || '';
        const b = selBrgy?.value || '';
        txtLoc.value = [b,c,p].filter(Boolean).join(', ');
      }
      function fillProvinces() {
        if (!selProv || selProv.dataset.filled === '1') return;
        const provinces = unique(window.ADDRESS_DATA.map(r => r.Province)).sort((a,b)=>a.localeCompare(b));
        provinces.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p; opt.textContent = p;
          selProv.appendChild(opt);
        });
        selProv.dataset.filled = '1';
      }

      selProv && selProv.addEventListener('change', function(){
        resetCity(); resetBrgy(); hidAdd.value = '';
        const prov = this.value;
        if (!prov) { composeLocation(); return; }
        const cities = unique(byProv(prov).map(r => r.City)).sort((a,b)=>a.localeCompare(b));
        cities.forEach(c => {
          const opt = document.createElement('option');
          opt.value = c; opt.textContent = c;
          selCity.appendChild(opt);
        });
        selCity.disabled = false;
        composeLocation();
      });

      selCity && selCity.addEventListener('change', function(){
        resetBrgy(); hidAdd.value = '';
        const prov = selProv.value;
        const city = this.value;
        if (!prov || !city) { composeLocation(); return; }
        const brgys = byProvCity(prov, city).map(r => ({name:r.Brgy, id:r.AddID}));
        brgys.forEach(obj => {
          const opt = document.createElement('option');
          opt.value = obj.name; opt.textContent = obj.name; opt.dataset.addid = obj.id;
          selBrgy.appendChild(opt);
        });
        selBrgy.disabled = false;
        composeLocation();
      });

      selBrgy && selBrgy.addEventListener('change', function(){
        const opt = this.selectedOptions[0];
        hidAdd.value = opt && opt.dataset.addid ? opt.dataset.addid : '';
        composeLocation();
      });

      window.__loc_reset = function(){
        fillProvinces();
        selProv.value=''; resetCity(); resetBrgy();
        txtLoc.value=''; hidAdd.value='';
      };

      window.__loc_loadFromText = function(text){
        fillProvinces();
        const saved = (text || '').split(',').map(s => s.trim());
        const [bSaved, cSaved, pSaved] = [saved[0]||'', saved[1]||'', saved[2]||''];
        if (pSaved && [...selProv.options].some(o=>o.value===pSaved)) {
          selProv.value = pSaved;
          resetCity(); resetBrgy();
          const cities = unique(byProv(pSaved).map(r => r.City)).sort((a,b)=>a.localeCompare(b));
          cities.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c; opt.textContent = c;
            if (c === cSaved) opt.selected = true;
            selCity.appendChild(opt);
          });
          selCity.disabled = false;
          if (cSaved) {
            const brgys = byProvCity(pSaved, cSaved).map(r => ({name:r.Brgy, id:r.AddID}));
            brgys.forEach(obj => {
              const opt = document.createElement('option');
              opt.value = obj.name; opt.textContent = obj.name; opt.dataset.addid = obj.id;
              if (obj.name === bSaved) opt.selected = true;
              selBrgy.appendChild(opt);
            });
            selBrgy.disabled = false;
            const selected = selBrgy.selectedOptions[0];
            hidAdd.value = selected && selected.dataset.addid ? selected.dataset.addid : '';
          }
        } else {
          selProv.value=''; resetCity(); resetBrgy(); hidAdd.value='';
        }
        composeLocation();
      };

      document.getElementById('openCreateModalBtn')?.addEventListener('click', fillProvinces, {once:true});
    })();
  </script>
</body>
</html>
