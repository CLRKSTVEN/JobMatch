<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Account Created</title>
</head>
<body style="font-family:Poppins,Arial,Helvetica,sans-serif;background:#f8fafc;padding:24px;color:#0f172a;">
  <table width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #e5e7eb;border-radius:12px">
    <tr>
      <td style="padding:24px;">
        <h2 style="margin:0 0 8px 0;font-size:20px;">Welcome!</h2>
        <p style="margin:0 0 16px 0;">Dear <?= htmlentities($full_name) ?>, your account has been created.</p>
        <ul style="margin:0 0 16px 20px;padding:0;line-height:1.6;">
          <li><b>Email:</b> <?= htmlentities($email) ?></li>
          <li><b>Temporary Password:</b> <?= htmlentities($password) ?></li>
          <li><b>Role:</b> <?= htmlentities($role) ?></li>
        </ul>
        <p style="margin:0 0 16px 0;">Please sign in and change your password immediately.</p>
        <p style="margin:0;color:#64748b;">Thank you,<br>School Admin</p>
      </td>
    </tr>
  </table>
</body>
</html>
