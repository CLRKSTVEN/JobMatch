<?php defined('BASEPATH') OR exit('No direct script access allowed');

class PesoDashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper(['url','form','html']);
        $this->load->library(['session','form_validation']);
        $this->load->model('Peso_model','peso');

        // Log what we actually have in session (helps diagnose prod)
        log_message(
            'debug',
            __CLASS__.'::__construct hit. logged_in='.(int)$this->session->userdata('logged_in')
            .' role=['.(string)$this->session->userdata('role').']'
            .' level=['.(string)$this->session->userdata('level').']'
        );

        // ⚠️ Allow public access to the JSON feed
        $method = strtolower($this->router->fetch_method());
        if (in_array($method, ['feed'], true)) {
            return; // no auth checks for the public feed
        }

        // Require login for everything else
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }

        if (!$this->is_peso_allowed()) {
            show_error('Forbidden (PESO only)', 403);
        }
    }

    /* ---------- Helpers ---------- */

    private function role_normalized(): string {
        $raw = (string)($this->session->userdata('role') ?: $this->session->userdata('level') ?: '');
        $r = strtolower(trim($raw));
        $r = str_replace(['_', '-'], ' ', $r);         // normalize underscores/dashes
        $r = preg_replace('/\s+/', ' ', $r);           // collapse extra spaces
        return $r;
    }

    private function is_peso_allowed(): bool {
        $r = $this->role_normalized();
        // TEMP: log normalized role
        log_message('debug', __CLASS__.' role normalized=['.$r.']');

        return (
            strpos($r, 'peso') !== false     // matches: "peso", "PESO_Officer", "peso-admin", etc.
            || $r === 'admin'
            || $r === 'tesda admin'
        );
    }

    private function me(): int
    {
        return (int) ($this->session->userdata('user_id')
            ?: $this->session->userdata('id')
            ?: 0);
    }

    /** Public JSON feed for login screen (OPEN + PUBLIC, latest first) */
    public function feed()
    {
        // Explicitly JSON response
        $this->output->set_content_type('application/json');

        // Optional limit via ?limit=12, default 10
        $limit = (int) $this->input->get('limit');
        if ($limit <= 0 || $limit > 50) { $limit = 10; }

        try {
            $rows = $this->peso->latest_public_open($limit);

            // Normalize shape/types a bit for the frontend
            foreach ($rows as &$r) {
                $r['id']            = (int)($r['id'] ?? 0);
                $r['title']         = (string)($r['title'] ?? '');
                $r['description']   = (string)($r['description'] ?? '');
                $r['location_text'] = (string)($r['location_text'] ?? '');
                $r['price_min']     = isset($r['price_min']) && $r['price_min'] !== '' ? (float)$r['price_min'] : null;
                $r['price_max']     = isset($r['price_max']) && $r['price_max'] !== '' ? (float)$r['price_max'] : null;
                $r['created_at']    = (string)($r['created_at'] ?? '');
                $r['website_url']   = isset($r['website_url']) ? (string)$r['website_url'] : '';
            }
            unset($r);

            $this->output->set_output(json_encode([
                'ok'   => true,
                'data' => $rows,
            ], JSON_UNESCAPED_UNICODE));
        } catch (Throwable $e) {
            // Don’t leak stack traces; keep it simple for the client
            $this->output
                ->set_status_header(500)
                ->set_output(json_encode([
                    'ok'      => false,
                    'error'   => 'server_error',
                    'message' => 'Unable to load feed.',
                ]));
        }
    }

    public function index()
    {
        $uid = $this->me();
        $list = $this->peso->mine($uid);

        $this->load->view('dashboard_peso', [
            'page_title' => 'PESO Dashboard',
            'list'       => $list
        ]);
    }

    public function store()
    {
        $this->form_validation->set_rules('title', 'Job Title', 'trim|required|max_length[200]');
        $this->form_validation->set_rules('post_type', 'Post Type', 'trim');
        $this->form_validation->set_rules('visibility', 'Visibility', 'trim');
        $this->form_validation->set_rules('price_min', 'Min', 'trim');
        $this->form_validation->set_rules('price_max', 'Max', 'trim');
        $this->form_validation->set_rules('website_url', 'Website', 'trim|valid_url'); // keep or relax if you want

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('danger', validation_errors());
            return redirect('dashboard/peso');
        }

        $this->peso->create($this->me(), $this->input->post(null, true));
        $this->session->set_flashdata('success', 'Job vacancy posted.');
        return redirect('dashboard/peso');
    }

    public function edit($id)
    {
        $uid = $this->me();
        $job = $this->peso->find($id, $uid);
        if (!$job) {
            $this->session->set_flashdata('danger', 'Record not found.');
            return redirect('dashboard/peso');
        }
        $list = $this->peso->mine($uid);
        $this->load->view('dashboard_peso', [
            'page_title' => 'PESO Dashboard',
            'list'       => $list,
            'edit'       => $job
        ]);
    }

    public function update($id)
    {
        $this->form_validation->set_rules('title', 'Job Title', 'trim|required|max_length[200]');
        $this->form_validation->set_rules('website_url', 'Website', 'trim|valid_url'); // keep or relax if you want

        if (!$this->form_validation->run()) {
            $this->session->set_flashdata('danger', validation_errors());
            return redirect('dashboard/peso');
        }
        $ok = $this->peso->update_job($id, $this->me(), $this->input->post(null, true));
        $this->session->set_flashdata($ok ? 'success' : 'danger', $ok ? 'Updated.' : 'Update failed.');
        return redirect('dashboard/peso');
    }

    public function toggle($id)
    {
        $ok = $this->peso->toggle_status($id, $this->me());
        $this->session->set_flashdata($ok ? 'success' : 'danger', $ok ? 'Status changed.' : 'Could not change status.');
        return redirect('dashboard/peso');
    }

    public function delete($id)
    {
        $ok = $this->peso->delete_job($id, $this->me());
        $this->session->set_flashdata($ok ? 'success' : 'danger', $ok ? 'Deleted.' : 'Delete failed.');
        return redirect('dashboard/peso');
    }
}
