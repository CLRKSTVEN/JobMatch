<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['recaptcha_site_key'] = '6Ld39twrAAAAAPQLYKunVpacvJkrpSR3re7BKgqn';
$config['recaptcha_secret']   = '6Ld39twrAAAAAFhs9D-9AOjAiNmkwXssFh3wO_eU';

// optional: strict remoteip check
$config['recaptcha_check_remoteip'] = true;
